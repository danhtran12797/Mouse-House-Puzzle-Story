package com.partner.example;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.adincube.sdk.AdinCube;
import com.adincube.sdk.AdinCubeInterstitialEventListener;

public class InterstitialActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.interstitialactivity);

        // setAppKey and Interstitial.init are called in HomeActivity

        findViewById(R.id.btnShow).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                // Call show to display an interstitial ad
                AdinCube.Interstitial.show(InterstitialActivity.this);
            }
        });

        // OPTIONAL - All events are called in UI thread.
        AdinCube.Interstitial.setEventListener(new AdinCubeInterstitialEventListener() {
            @Override public void onAdCached() { // an interstitial ad has been cached and is now ready to be shown.
                log("onAdCached");
            }
            @Override public void onAdShown() { // an interstitial ad is shown.
                log("onAdShown");
            }
            @Override public void onError(String errorCode) { // no ad could be shown after a show() call.
                log("onError: "+errorCode);
            }
            @Override public void onAdClicked() { // an interstitial ad has been clicked.
                log("onAdClicked");
            }
            @Override public void onAdHidden() { // an interstitial ad has been closed.
                log("onAdHidden");
            }
        });
    }

    private void log(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        Log.d("AdinCube", msg);
    }
}
