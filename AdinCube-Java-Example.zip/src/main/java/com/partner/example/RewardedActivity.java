package com.partner.example;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.adincube.sdk.AdinCube;
import com.adincube.sdk.AdinCubeRewardedEventListener;

public class RewardedActivity extends Activity {

    private boolean displayRewardDialog = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rewardedactivity);
        bindViews();

        // setAppKey is called in HomeActivity

        btnFetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Fetch a rewarded ad
                AdinCube.Rewarded.fetch(RewardedActivity.this);
            }
        });

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Call show to display a rewarded ad
                AdinCube.Rewarded.show(RewardedActivity.this);
            }
        });

        // MANDATORY - Register an event listener to be notified when the user has completed the video.
        // All events are called in UI thread.
        AdinCube.Rewarded.setEventListener(new AdinCubeRewardedEventListener() {
            @Override public void onAdCompleted() { // user has completed the video
                log("onAdCompleted");

                giveRewardToUser();
                displayRewardDialog = true;
            }

            // OPTIONAL - Other events
            @Override public void onAdFetched() { // a rewarded ad has been fetched and is ready to be shown
                log("onAdFetched");
                btnShow.setEnabled(true);
            }
            @Override public void onAdShown() { // a rewarded ad is shown.
                log("onAdShown");
                btnShow.setEnabled(false);
            }
            @Override public void onAdClicked() {
                log("onAdClicked");
            }
            @Override public void onError(String errorCode) { // no ad could be shown after a show() call.
                log("onError - " + errorCode);
            }
            @Override public void onAdHidden() { // a rewarded ad has been closed.
                log("onAdHidden");
            }
        });
    }

    private void log(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        Log.d("AdinCube", msg);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (displayRewardDialog) {
            displayRewardDialog = false;
            new AlertDialog.Builder(RewardedActivity.this)
                    .setTitle("onAdCompleted")
                    .setMessage("Reward received!")
                    .setPositiveButton("Ok", null)
                    .show();
        }
    }

    private void giveRewardToUser() {
        // TODO
    }

    private Button btnFetch;
    private Button btnShow;

    private void bindViews() {
        btnFetch = (Button) findViewById(R.id.btnFetch);
        btnShow = (Button) findViewById(R.id.btnShow);
    }
}
