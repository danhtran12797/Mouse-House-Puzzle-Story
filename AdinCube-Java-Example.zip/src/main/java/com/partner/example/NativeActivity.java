package com.partner.example;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.adincube.sdk.AdinCube;
import com.adincube.sdk.NativeAd;
import com.adincube.sdk.nativead.NativeAdViewBinder;
import com.adincube.sdk.nativead.NativeAdViewBinderEventListener;
import com.adincube.sdk.nativead.NativeAdViewBinding;

public class NativeActivity extends Activity {

    private NativeAd nativeAd;

    private NativeAdViewBinder viewBinder;

    private LinearLayout llRoot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nativeactivity);
        bindViews();

        nativeAd = null;

        // Bind your native ad to your layout
        NativeAdViewBinding binding = new NativeAdViewBinding.Builder(R.layout.nativead)
                .withTitleViewId(R.id.title)
                .withCallToActionViewId(R.id.callToAction)
                .withDescriptionViewId(R.id.description)
                .withRatingViewId(R.id.rating)
                .withIconViewId(R.id.icon)
                .withMediaViewId(R.id.media)
                .withAdChoicesViewId(R.id.adChoices)
                .build();

        // Create the binder
        this.viewBinder = new NativeAdViewBinder(this, binding);

        // Get your view
        // Event listener is OPTIONAL - All events are called in UI thread.
        View nativeAdView = this.viewBinder.get(new NativeAdViewBinderEventListener() {
            @Override public void onAdLoaded(ViewGroup viewGroup) { // a native ad has been loaded.
                log("onAdLoaded");
            }
            @Override public void onLoadError(ViewGroup viewGroup, String errorCode) { // // no ad could be loaded.
                log("onLoadError: " + errorCode);
            }
            @Override public void onAdClicked(ViewGroup viewGroup) { // a native ad has been clicked.
                log("onAdClicked");
            }
        });

        // Add the view to your layout
        llRoot.addView(nativeAdView);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AdinCube.Native.destroy(nativeAd); // The native ad will not be displayed anymore
    }

    private void bindViews() {
        llRoot = (LinearLayout) findViewById(R.id.llRoot);
    }

    private void log(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        Log.d("AdinCube", msg);
    }
}
