package com.partner.example;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.adincube.sdk.AdinCube;
import com.adincube.sdk.AdinCubeBannerEventListener;
import com.adincube.sdk.BannerView;

public class BannerActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.banneractivity);

        // setAppKey is called in HomeActivity

        // Get a reference to your banner
        BannerView bannerView = (BannerView) findViewById(R.id.bannerView);

        // OPTIONAL - All events are called in UI thread.
        AdinCube.Banner.setEventListener(bannerView, eventListener);

        // Load a banner ad
        AdinCube.Banner.load(bannerView);
    }

    private final AdinCubeBannerEventListener eventListener = new AdinCubeBannerEventListener() {
        @Override public void onAdLoaded(BannerView bannerView) { // a banner ad has been loaded.
            log("onAdLoaded");
        }
        @Override public void onLoadError(BannerView bannerView, String errorCode) { // no banned ad could be loaded after a load() call.
            log("onLoadError: " + errorCode);
        }
        @Override public void onAdShown(BannerView bannerView) { // a banner ad is shown.
            log("onAdShown");
        }
        @Override public void onError(BannerView bannerView, String errorCode) { // no banned ad could be shown.
            log("onError: " + errorCode);
        }
        @Override public void onAdClicked(BannerView bannerView) { // a banner ad has been clicked.
            log("onAdClicked");
        }
    };

    private void log(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        Log.d("AdinCube", msg);
    }
}
