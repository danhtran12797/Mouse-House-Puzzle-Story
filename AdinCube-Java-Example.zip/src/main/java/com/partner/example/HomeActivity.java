package com.partner.example;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.adincube.sdk.AdinCube;

public class HomeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homeactivity);
        bindViews();

        AdinCube.setAppKey("TEST_APP_KEY"); // Replace with your app key

        // Display a dialog to collect user consent to be compliant with GDPR regulation in EEA.
        AdinCube.UserConsent.ask(this);

        AdinCube.Interstitial.init(this);   // Start caching interstitial ads
    }

    private void bindViews() {
        findViewById(R.id.btnInterstitial).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, InterstitialActivity.class));
            }
        });

        findViewById(R.id.btnBanner).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, BannerActivity.class));
            }
        });

        findViewById(R.id.btnRewarded).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, RewardedActivity.class));
            }
        });

        findViewById(R.id.btnNative).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, NativeActivity.class));
            }
        });
    }
}
